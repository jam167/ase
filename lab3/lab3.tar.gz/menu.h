
/**************************************************************************************************/
/* Copyright (C) SSE-USTC, 2014-2015                                                              */
/*                                                                                                */
/*  FILE NAME             :  menu.h                                                               */
/*  PRINCIPAL AUTHOR      :  Jiangwenzhong                                                        */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/22                                                           */
/*  DESCRIPTION           :  interface of menu                                                    */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Jiangwenzhong,2014/09/22
 *
 */

#ifndef _MENU_H_
#define _MENU_H_

#include <stdio.h>
#include <stdlib.h>

/*
 * Menu Type
 */
typedef struct Menu tMenu;

/*
 * Command Type
 */
typedef struct Cmd tCmd;

/*
 * Init a Menu
 */
tMenu * InitMenu();

/*
 * Delete a Menu
 */
int DeleteMenu(tMenu * head);

/*
 * Add a Command
 */
int AddCmd(tMenu * head, char * cmd, char * desc, int (* handler)());

/*
 * Show all commands in Menu
 */
int ShowAllCmd(tMenu * head);

/*
 * Start Menu
 */
int StartMenu(tMenu * head);

#endif /* _MENU_H_ */
