
/**************************************************************************************************/
/* Copyright (C) SSE-USTC, 2014-2015                                                              */
/*                                                                                                */
/*  FILE NAME             :  test.c                                                               */
/*  PRINCIPAL AUTHOR      :  Jiangwenzhong                                                        */
/*  SUBSYSTEM NAME        :  test                                                                 */
/*  MODULE NAME           :  test                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/22                                                           */
/*  DESCRIPTION           :  test driver of menu                                                  */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Jiangwenzhong,2014/09/22
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "menu.h"

#define DEBUG printf
#define SUCC 0
#define FAIL 1

int result[5] = {FAIL, FAIL, FAIL, FAIL, FAIL};
char * info[5] =
{
    "InitMenu",
    "AddCmd",
    "StartMenu",
    "ShowAllCmd",
    "DeleteMenu"
};

int main()
{
    int i = 0;
    int ret = FAIL;
    char * cmd = "testcmd";
    char * desc = "this is a test cmd";
    int testfunc();

    /* test interface */
    tMenu * p = InitMenu();
    if(p == NULL)
    {
        DEBUG("Error! - %s\n", info[0]);
        result[0] = FAIL;
    }
    else
    {
        result[0] = SUCC;
    }
    ret = AddCmd(p, cmd, desc, testfunc);
    if(ret == FAIL)
    {
        DEBUG("Error! - %s\n",info[1]);
        result[1] = FAIL;
    }
    else
    {
        result[1] = SUCC;
    }
    ret = StartMenu(p);
    if(ret == FAIL)
    {
        DEBUG("Error! - %s\n",info[2]);
        result[2] = FAIL;
    }
    else
    {
        result[2] = SUCC;
    }
    ret = ShowAllCmd(p);
    if(ret == FAIL)
    {
        DEBUG("Error! - %s\n",info[3]);
        result[3] = FAIL;
    }
    else
    {
        result[3] = SUCC;
    }
    ret = DeleteMenu(p);
    if(ret == FAIL)
    {
        DEBUG("Error! - %s\n",info[4]);
        result[4] = FAIL;
    }
    else
    {
        result[4] = SUCC;
    }

    /* test report */
    printf("Test Report :\n");
    for(i=0; i<5; i++)
    {
        printf("Testcase Number %d %s - %s\n", i+1, (result[i])?"Failed":"Succeeded", info[i]);
    }
}

int testfunc()
{
    return 0;
}
