
/**************************************************************************************************/
/* Copyright (C) SSE-USTC, 2014-2015                                                              */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  Jiangwenzhong                                                        */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/22                                                           */
/*  DESCRIPTION           :  interface of menu                                                    */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Jiangwenzhong,2014/09/22
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "menu.h"

/*
 * Menu Type
 */
struct Menu
{
    tMenu * menuhead;
    tCmd * cmdhead;
};

/*
 * Command Type
 */
struct Cmd
{
    char * cmd;
    char * desc;
    int (* handler)();
    tCmd * next;
};

/*
 * Init a Menu
 */
tMenu * InitMenu()
{
    tMenu * p = (tMenu *)malloc(sizeof(tMenu));
    return p;
}

/*
 * Delete a Menu
 */
int DeleteMenu(tMenu * head)
{
    if(head != NULL)
    {
        return 0;
    }
}

/*
 * Add a Command
 */
int AddCmd(tMenu * head, char * cmd, char * desc, int (* handler)())
{
    if(head != NULL && cmd != NULL && desc != NULL && handler != NULL)
    {
        return 0;
    }
}

/*
 * Show all commands in Menu
 */
int ShowAllCmd(tMenu * head)
{
    if(head != NULL)
    {
        return 0;
    }
}

/*
 * Start Menu
 */
int StartMenu(tMenu * head)
{
    if(head != NULL)
    {
        return 0;
    }
}
